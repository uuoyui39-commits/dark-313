# DARK STORE | متجر دارك

متجر إلكتروني مفتوح للزوار (بدون تسجيل) مبني بـ React + Vite + Firebase. التسجيل للأدمن فقط عبر `/dashboard`.

## 1) إعداد Firebase
1. أنشئ مشروعاً في https://console.firebase.google.com
2. فعّل: **Authentication** (Email/Password) و **Firestore** و **Storage** و **Hosting**.
3. أضف تطبيق Web وانسخ الإعدادات.
4. انسخ `.env.example` إلى `.env` وعبّئ القيم.

## 2) إنشاء الأدمن
1. من Authentication ← Users أضف مستخدماً (بريد وكلمة مرور) وانسخ **UID**.
2. من Firestore أنشئ مجموعة `admins` ثم مستند **رقمه = UID** (يمكن أن يحتوي أي حقل مثل `role: "admin"`).
   (لا يمكن إنشاؤه من التطبيق عمداً، لأسباب أمنية.)

## 3) التشغيل
```
npm install
npm run dev
```

## 4) النشر وقواعد الأمان
```
npm install -g firebase-tools
firebase login
firebase init   # اختر Hosting + Firestore + Storage، واستخدم الملفات الموجودة (dist، firestore.rules، storage.rules) دون استبدالها
npm run build
firebase deploy
```

## 5) الاستخدام
ادخل `/dashboard` ← من تبويب **المتجر** عدّل الاسم والشعار والألوان وWhatsApp وTelegram، ثم أنشئ الأقسام، ثم المنتجات.
العروض: ضع سعراً قديماً أو نسبة خصم في المنتج فيظهر في قسم العروض تلقائياً.

## الهيكل
- `src/services/api.js` الاتصال بـ Firestore/Storage
- `src/pages` الصفحات (الرئيسية، المنتج، الإدارة)
- `src/components` مكونات مشتركة
- `firestore.rules` و `storage.rules` قواعد الأمان
