import {Link} from 'react-router-dom';import {fmt} from '../services/api';
export default function ProductCard({p}){
 const off=p.oldPrice>p.price?Math.round((1-p.price/p.oldPrice)*100):p.discount||0;
 return <Link to={`/product/${p.id}`} className="card">
  <div className="img">{p.image?<img src={p.image} alt={p.name} loading="lazy"/>:null}{off>0&&<b className="badge">-{off}%</b>}{!p.available&&<b className="badge out">غير متوفر</b>}</div>
  <h3>{p.name}</h3><div className="price">{fmt(p.price)}{p.oldPrice>p.price&&<s>{fmt(p.oldPrice)}</s>}</div></Link>;
}
