import {useState} from 'react';import {uploadImage,deleteImage} from '../services/api';import {useApp} from '../App';
export default function ImageInput({value,onChange,folder}){
 const [busy,setBusy]=useState(false),{notify}=useApp();
 const pick=async e=>{const f=e.target.files[0];if(!f)return;setBusy(true);
  try{const url=await uploadImage(f,folder);if(value)await deleteImage(value);onChange(url)}catch{notify('فشل رفع الصورة','err')}setBusy(false)};
 const del=async()=>{await deleteImage(value);onChange('')};
 return <div className="imgin">{value&&<img src={value} alt=""/>}<label className="btn sm">{busy?'جارٍ الرفع...':value?'تغيير الصورة':'رفع صورة'}<input hidden type="file" accept="image/*" onChange={pick}/></label>{value&&<button type="button" className="btn sm danger" onClick={del}>حذف الصورة</button>}</div>;
}
