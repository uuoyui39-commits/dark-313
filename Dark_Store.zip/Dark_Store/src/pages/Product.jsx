import {useEffect,useState} from 'react';import {useParams,Link} from 'react-router-dom';
import {getProduct,addView,fmt,waLink,tgLink,orderText} from '../services/api';import {useApp} from '../App';
export default function Product(){
 const {id}=useParams(),{settings:s,notify}=useApp(),[p,setP]=useState(undefined),[tg,setTg]=useState(false);
 useEffect(()=>{getProduct(id).then(r=>{setP(r);if(r)addView(id)})},[id]);
 if(p===undefined)return <p className="empty">جارٍ التحميل...</p>;
 if(!p)return <div className="empty"><h1>404</h1><p>المنتج غير موجود</p><Link className="btn" to="/">العودة للمتجر</Link></div>;
 const copy=async()=>{try{await navigator.clipboard.writeText(orderText(p));notify('تم نسخ رسالة الطلب')}catch{notify('تعذر النسخ','err')}};
 return <main className="wrap pd"><Link to="/" className="muted">← الرئيسية</Link>
  <div className="pgrid"><div className="img big">{p.image&&<img src={p.image} alt={p.name}/>}</div>
  <div><h1>{p.name}</h1><div className="price big">{fmt(p.price)}{p.oldPrice>p.price&&<s>{fmt(p.oldPrice)}</s>}</div>
   <p className={p.available?'ok':'no'}>{p.available?'● متوفر':'● غير متوفر'}</p>
   <p className="pre">{p.description}</p>{p.details&&<><h3>التفاصيل</h3><p className="pre">{p.details}</p></>}
   <div className="row">{s.whatsapp&&<a className="btn wa" target="_blank" rel="noreferrer" href={waLink(s.whatsapp,p)}>اشترِ عبر WhatsApp</a>}
   {s.telegram&&<button className="btn tg" onClick={()=>setTg(true)}>تواصل عبر Telegram</button>}</div></div></div>
  {tg&&<div className="modal" onClick={()=>setTg(false)}><div className="box" onClick={e=>e.stopPropagation()}><h3>تفاصيل الطلب</h3><pre>{orderText(p)}</pre>
   <div className="row"><button className="btn" onClick={copy}>نسخ رسالة الطلب</button><a className="btn tg" target="_blank" rel="noreferrer" href={tgLink(s.telegram)}>فتح Telegram</a></div></div></div>}
 </main>;
}
