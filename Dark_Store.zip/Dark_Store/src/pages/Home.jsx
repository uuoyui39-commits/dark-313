import {useEffect,useMemo,useState} from 'react';import {getCategories,getProducts,tgLink} from '../services/api';
import {useApp} from '../App';import ProductCard from '../components/ProductCard';
export default function Home(){
 const {settings:s}=useApp(),[cats,setCats]=useState([]),[prods,setProds]=useState([]),[load,setLoad]=useState(true),[err,setErr]=useState(false);
 const [q,setQ]=useState(''),[cat,setCat]=useState(''),[sort,setSort]=useState('new');
 useEffect(()=>{Promise.all([getCategories(true),getProducts(true)]).then(([c,p])=>{setCats(c);setProds(p)}).catch(()=>setErr(true)).finally(()=>setLoad(false))},[]);
 const ts=p=>p.createdAt?.seconds||0,isOffer=p=>p.oldPrice>p.price||p.discount>0;
 const filtered=useMemo(()=>{let a=prods.filter(p=>(!cat||p.categoryId===cat)&&(!q||(p.name+' '+(p.description||'')).includes(q)));
  if(sort==='low')a.sort((x,y)=>x.price-y.price);else if(sort==='high')a.sort((x,y)=>y.price-x.price);else a.sort((x,y)=>ts(y)-ts(x));return a},[prods,q,cat,sort]);
 const searching=q||cat;
 const Sec=({t,a})=>a.length?<section><h2>{t}</h2><div className="grid">{a.map(p=><ProductCard key={p.id} p={p}/>)}</div></section>:null;
 const Sort=<select value={sort} onChange={e=>setSort(e.target.value)}><option value="new">الأحدث</option><option value="low">السعر: الأقل</option><option value="high">السعر: الأعلى</option></select>;
 return <>
 <header className="hero"><div className="logo">{s.logo?<img src={s.logo} alt=""/>:'DS'}</div>
  <h1>{s.name||'DARK STORE'}</h1><p>{s.desc}</p>
  <input className="search" placeholder="ابحث عن منتج..." value={q} onChange={e=>setQ(e.target.value)}/></header>
 <main className="wrap">
  <div className="chips"><button className={!cat?'on':''} onClick={()=>setCat('')}>الكل</button>{cats.map(c=><button key={c.id} className={cat===c.id?'on':''} onClick={()=>setCat(c.id)}>{c.image&&<img src={c.image} alt=""/>}{c.name}</button>)}</div>
  {cat&&<p className="muted">{cats.find(c=>c.id===cat)?.description}</p>}
  {load&&<p className="muted">جارٍ التحميل...</p>}{err&&<p className="muted">تعذر تحميل البيانات. تحقق من إعدادات Firebase.</p>}
  {!load&&!err&&!prods.length&&<p className="muted">لا توجد منتجات منشورة بعد.</p>}
  {searching?<section><div className="bar"><h2>النتائج ({filtered.length})</h2>{Sort}</div>
   <div className="grid">{filtered.map(p=><ProductCard key={p.id} p={p}/>)}</div></section>:<>
   <Sec t="المنتجات المميزة" a={prods.filter(p=>p.featured)}/>
   <Sec t="العروض والخصومات" a={prods.filter(isOffer)}/>
   <Sec t="الأكثر مشاهدة" a={[...prods].filter(p=>p.views>0).sort((a,b)=>b.views-a.views).slice(0,6)}/>
   {filtered.length>0&&<section><div className="bar"><h2>أحدث المنتجات</h2>{Sort}</div>
   <div className="grid">{filtered.map(p=><ProductCard key={p.id} p={p}/>)}</div></section>}</>}
 </main>
 <footer><h3>تواصل معنا</h3><div className="row">
  {s.whatsapp&&<a className="btn wa" href={`https://wa.me/${s.whatsapp.replace(/\D/g,'')}`} target="_blank" rel="noreferrer">WhatsApp</a>}
  {s.telegram&&<a className="btn tg" href={tgLink(s.telegram)} target="_blank" rel="noreferrer">Telegram</a>}</div>
  <p className="muted">© {new Date().getFullYear()} {s.name||'DARK STORE'}</p></footer></>;
}
