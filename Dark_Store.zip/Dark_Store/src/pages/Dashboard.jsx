import {useEffect,useState} from 'react';import {Link} from 'react-router-dom';
import {onAuthStateChanged,signInWithEmailAndPassword,signOut} from 'firebase/auth';import {doc,getDoc} from 'firebase/firestore';
import {auth,db} from '../firebase';import {getCategories,getProducts,saveItem,removeItem,saveSettings,deleteImage} from '../services/api';
import {useApp} from '../App';import ImageInput from '../components/ImageInput';
const F=({l,children})=><label className="f"><span>{l}</span>{children}</label>;
function Cats(){
 const {notify}=useApp(),[a,setA]=useState([]),[e,setE]=useState(null);
 const load=()=>getCategories(false).then(setA);useEffect(()=>{load()},[]);
 const save=async ev=>{ev.preventDefault();const {id,createdAt,...d}=e;d.order=+d.order||0;try{await saveItem('categories',d,id);notify('تم الحفظ');setE(null);load()}catch{notify('فشل الحفظ','err')}};
 const del=async c=>{if(!confirm('حذف القسم؟'))return;try{await removeItem('categories',c.id);await deleteImage(c.image);notify('تم الحذف');load()}catch{notify('فشل الحذف','err')}};
 const set=k=>v=>setE({...e,[k]:v});
 return <div><button className="btn" onClick={()=>setE({name:'',description:'',image:'',order:a.length+1,visible:true})}>+ قسم جديد</button>
 {e&&<form className="panel" onSubmit={save}><F l="اسم القسم"><input required value={e.name} onChange={x=>set('name')(x.target.value)}/></F>
  <F l="الوصف"><textarea value={e.description} onChange={x=>set('description')(x.target.value)}/></F>
  <F l="الترتيب"><input type="number" value={e.order} onChange={x=>set('order')(x.target.value)}/></F>
  <F l="الصورة / الأيقونة"><ImageInput folder="categories" value={e.image} onChange={set('image')}/></F>
  <label className="chk"><input type="checkbox" checked={!!e.visible} onChange={x=>set('visible')(x.target.checked)}/> ظاهر</label>
  <div className="row"><button className="btn">حفظ</button><button type="button" className="btn sm" onClick={()=>setE(null)}>إلغاء</button></div></form>}
 {a.map(c=><div className="item" key={c.id}><span>{c.order}. {c.name} {!c.visible&&'(مخفي)'}</span><span><button className="btn sm" onClick={()=>setE({...c})}>تعديل</button> <button className="btn sm danger" onClick={()=>del(c)}>حذف</button></span></div>)}</div>;
}
function Prods(){
 const {notify}=useApp(),[a,setA]=useState([]),[cats,setCats]=useState([]),[e,setE]=useState(null);
 const load=()=>{getProducts(false).then(setA);getCategories(false).then(setCats)};useEffect(()=>{load()},[]);
 const save=async ev=>{ev.preventDefault();const {id,createdAt,...d}=e;d.price=+d.price;d.oldPrice=d.oldPrice===''?0:+d.oldPrice;d.discount=+d.discount||0;d.views=d.views||0;
  try{await saveItem('products',d,id);notify('تم الحفظ');setE(null);load()}catch{notify('فشل الحفظ','err')}};
 const del=async p=>{if(!confirm('حذف المنتج؟'))return;try{await removeItem('products',p.id);await deleteImage(p.image);notify('تم الحذف');load()}catch{notify('فشل الحذف','err')}};
 const set=k=>v=>setE({...e,[k]:v}),t=k=>({value:e[k]??'',onChange:x=>set(k)(x.target.value)}),c=k=>({checked:!!e[k],onChange:x=>set(k)(x.target.checked)});
 return <div><button className="btn" disabled={!cats.length} onClick={()=>setE({name:'',price:'',oldPrice:'',discount:'',description:'',details:'',image:'',categoryId:cats[0].id,available:true,featured:false,visible:true})}>+ منتج جديد</button>{!cats.length&&<span className="muted"> أنشئ قسماً أولاً</span>}
 {e&&<form className="panel" onSubmit={save}><F l="اسم المنتج"><input required {...t('name')}/></F>
  <F l="القسم"><select {...t('categoryId')}>{cats.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select></F>
  <F l="السعر (د.ع)"><input required type="number" min="0" {...t('price')}/></F><F l="السعر القديم (اختياري)"><input type="number" min="0" {...t('oldPrice')}/></F>
  <F l="نسبة الخصم % (اختياري)"><input type="number" min="0" max="100" {...t('discount')}/></F>
  <F l="الوصف"><textarea {...t('description')}/></F><F l="تفاصيل إضافية"><textarea {...t('details')}/></F>
  <F l="الصورة"><ImageInput folder="products" value={e.image} onChange={set('image')}/></F>
  <label className="chk"><input type="checkbox" {...c('available')}/> متوفر</label><label className="chk"><input type="checkbox" {...c('featured')}/> مميز</label><label className="chk"><input type="checkbox" {...c('visible')}/> ظاهر</label>
  <div className="row"><button className="btn">حفظ</button><button type="button" className="btn sm" onClick={()=>setE(null)}>إلغاء</button></div></form>}
 {a.map(p=><div className="item" key={p.id}><span>{p.name} — {p.price} {!p.visible&&'(مخفي)'}</span><span><button className="btn sm" onClick={()=>setE({...p})}>تعديل</button> <button className="btn sm danger" onClick={()=>del(p)}>حذف</button></span></div>)}</div>;
}
function Store(){
 const {settings,reload,notify}=useApp(),[s,setS]=useState(settings);useEffect(()=>setS(settings),[settings]);
 const t=k=>({value:s[k]||'',onChange:x=>setS({...s,[k]:x.target.value})});
 const save=async ev=>{ev.preventDefault();try{await saveSettings(s);await reload();notify('تم حفظ الإعدادات')}catch{notify('فشل الحفظ','err')}};
 return <form className="panel" onSubmit={save}><F l="اسم المتجر"><input {...t('name')}/></F><F l="الوصف"><textarea {...t('desc')}/></F>
  <F l="الشعار"><ImageInput folder="store" value={s.logo} onChange={v=>setS({...s,logo:v})}/></F>
  <F l="اللون الأساسي"><input type="color" value={s.primary||'#8b5cf6'} onChange={x=>setS({...s,primary:x.target.value})}/></F>
  <F l="اللون الثانوي"><input type="color" value={s.secondary||'#22d3ee'} onChange={x=>setS({...s,secondary:x.target.value})}/></F>
  <F l="رقم WhatsApp (بصيغة دولية مثل 9647xxxxxxxxx)"><input dir="ltr" {...t('whatsapp')}/></F><F l="رابط أو معرف Telegram"><input dir="ltr" {...t('telegram')}/></F>
  <p className="muted">العروض: أضف سعراً قديماً أو نسبة خصم في المنتج ليظهر تلقائياً في قسم العروض.</p><button className="btn">حفظ الإعدادات</button></form>;
}
export default function Dashboard(){
 const {notify}=useApp(),[u,setU]=useState(undefined),[ok,setOk]=useState(false),[tab,setTab]=useState('products'),[em,setEm]=useState(''),[pw,setPw]=useState('');
 useEffect(()=>onAuthStateChanged(auth,async x=>{setOk(false);if(x){try{setOk((await getDoc(doc(db,'admins',x.uid))).exists())}catch{}}setU(x)}),[]);
 const login=async ev=>{ev.preventDefault();try{await signInWithEmailAndPassword(auth,em,pw)}catch{notify('بيانات الدخول غير صحيحة','err')}};
 if(u===undefined)return <p className="empty">جارٍ التحميل...</p>;
 if(!u)return <form className="panel login" onSubmit={login}><h2>دخول الإدارة</h2><input type="email" placeholder="البريد الإلكتروني" dir="ltr" required value={em} onChange={e=>setEm(e.target.value)}/><input type="password" placeholder="كلمة المرور" dir="ltr" required value={pw} onChange={e=>setPw(e.target.value)}/><button className="btn">دخول</button></form>;
 if(!ok)return <div className="empty"><p>هذا الحساب غير مصرح له بالإدارة.</p><button className="btn" onClick={()=>signOut(auth)}>تسجيل الخروج</button></div>;
 return <main className="wrap"><div className="bar"><h2>لوحة الإدارة</h2><span><Link className="btn sm" to="/">المتجر</Link> <button className="btn sm" onClick={()=>signOut(auth)}>خروج</button></span></div>
  <div className="chips">{[['products','المنتجات'],['cats','الأقسام'],['store','المتجر']].map(([k,l])=><button key={k} className={tab===k?'on':''} onClick={()=>setTab(k)}>{l}</button>)}</div>
  {tab==='products'?<Prods/>:tab==='cats'?<Cats/>:<Store/>}</main>;
}
