import {createContext,useContext,useEffect,useState,useCallback} from 'react';
import {Routes,Route,Link} from 'react-router-dom';
import {getSettings} from './services/api';
import Home from './pages/Home';import Product from './pages/Product';import Dashboard from './pages/Dashboard';
const Ctx=createContext();export const useApp=()=>useContext(Ctx);
export default function App(){
 const [settings,setSettings]=useState({}),[toast,setT]=useState(null);
 const notify=useCallback((msg,type='ok')=>{setT({msg,type});setTimeout(()=>setT(null),3500)},[]);
 const reload=useCallback(()=>getSettings().then(setSettings),[]);
 useEffect(()=>{reload()},[reload]);
 useEffect(()=>{const r=document.documentElement.style;r.setProperty('--p',settings.primary||'#8b5cf6');r.setProperty('--s',settings.secondary||'#22d3ee');
  document.title=`${settings.name||'DARK STORE'} | متجر دارك`},[settings]);
 return <Ctx.Provider value={{settings,reload,notify}}>
  <Routes><Route path="/" element={<Home/>}/><Route path="/product/:id" element={<Product/>}/>
  <Route path="/dashboard" element={<Dashboard/>}/><Route path="*" element={<div className="empty"><h1>404</h1><p>الصفحة غير موجودة</p><Link className="btn" to="/">العودة للمتجر</Link></div>}/></Routes>
  {toast&&<div className={'toast '+toast.type}>{toast.msg}</div>}</Ctx.Provider>;
}
